//
//  Array+Identifiable.swift
//  Lecture1
//
//  Created by 王良壮 on 2020/7/23.
//  Copyright © 2020 lzwang. All rights reserved.
//

import Foundation

// 代码复用，index与card都可以使用此extension
extension Array where Element: Identifiable {
    func firstIndex(matching: Element) -> Int? { // Optional Int
        for index in 0..<self.count{
            if self[index].id == matching.id {
                return index
            }
        }
        return nil
    }
}
