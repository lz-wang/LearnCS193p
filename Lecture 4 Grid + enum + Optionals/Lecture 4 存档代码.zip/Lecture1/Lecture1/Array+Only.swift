//
//  Array+Only.swift
//  Lecture1
//
//  Created by 王良壮 on 2020/7/23.
//  Copyright © 2020 lzwang. All rights reserved.
//

import Foundation

extension Array {
    var only: Element? {
        count == 1 ? first : nil
    }
}
